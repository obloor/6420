# ISCG6420_2024_S2
This repository contains distributed course content and examples for ISCG6420 Internet & Web Development (2024 Semester 2).